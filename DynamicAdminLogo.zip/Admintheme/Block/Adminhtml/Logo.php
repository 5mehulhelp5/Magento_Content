<?php
namespace Aventure7\Admintheme\Block\Adminhtml;

use Magento\Framework\View\Element\Template;
use Magento\Store\Model\StoreManagerInterface;

class Logo extends Template
{
    protected $storeManager;
    protected $_scopeConfig;
    protected $_logo;

    public function __construct(
        Template\Context $context,
        \Magento\Theme\Block\Html\Header\Logo $logo,
        StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        $this->storeManager = $storeManager;
         $this->_logo = $logo;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $data);
    }
   

    public function getWebsiteLogoUrl()
    {
        $logoPath = $this->_scopeConfig->getValue(
            'design/header/logo_src',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        return $logoPath ? $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'logo/' . $logoPath : '';
    }

    public function getBaseUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl();
    }

    public function getAdminDefaultLogo()
    {
        return $this->_logo->getLogoSrc();
    }

    public function getAdminLogoAlt()
    {    
        return $this->_logo->getLogoAlt();
    }
    
    public function getAdminLogoWidth()
    {    
        return $this->_logo->getLogoWidth();
    }
    
    public function getAdminLogoHeight()
    {    
        return $this->_logo->getLogoHeight();
    }  
   
}
